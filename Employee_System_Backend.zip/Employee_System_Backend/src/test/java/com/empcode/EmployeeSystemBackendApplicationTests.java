package com.empcode;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmployeeSystemBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
